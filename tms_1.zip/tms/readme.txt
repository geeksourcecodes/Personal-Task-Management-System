task management sysytem credentials 
admin ,,,,admin admin 
users ,,username  pass>1234
for more details see database tms 
..how to configugure 
1 create new database , name it tms
2 import database inside the folder named database , tms.sql ,and click go 
3 run the system  tthank you my contacts tremendouschatikobo@gmail.com/+263778046755
if you lyk project or website get in touch with me . 
liink on how to configure 